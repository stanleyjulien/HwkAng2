export class Item
{
    // We consider product as Item
}