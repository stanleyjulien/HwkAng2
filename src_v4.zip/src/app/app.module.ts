import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {CartModule} from './modules/cart.module';

import { AppComponent } from './app.component';
import { ProductsListComponent } from './componentfiles/products-list.component';
import { ProductsDetailComponent } from './componentfiles/product-detail.component';
import { ProductService } from './services/ProductService';
import { ProductFormComponent } from './componentfiles/ProductFormComponent';


@NgModule({
  declarations: [
    AppComponent, ProductsListComponent, ProductsDetailComponent,ProductFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CartModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
