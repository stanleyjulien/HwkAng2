import { NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { CartService } from '../services/CartService';
import { CartComponent } from '../componentfiles/cart.component';
import { CartPipe } from '../componentfiles/CartPipe';

@NgModule({
  declarations: [
    CartComponent, CartPipe
  ],
  imports: [
    CommonModule,
  ],
  exports:[
    CartComponent, CartPipe
  ],
  providers: [CartService]
})
export class CartModule { }
